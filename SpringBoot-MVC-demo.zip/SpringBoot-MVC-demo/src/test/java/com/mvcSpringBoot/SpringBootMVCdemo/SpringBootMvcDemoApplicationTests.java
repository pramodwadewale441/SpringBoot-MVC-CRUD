package com.mvcSpringBoot.SpringBootMVCdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMvcDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
